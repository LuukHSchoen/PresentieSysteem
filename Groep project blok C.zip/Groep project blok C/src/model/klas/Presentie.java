package model.klas;

import java.time.LocalDate;
import java.util.ArrayList;

import model.persoon.Student;

public class Presentie {
	
	private ArrayList<Student> studentPresentie;
	private ArrayList<College> deColleges;
	
	
	
	public void presentieToevoegen(Student pStudent, LocalDate absDatum){
		
	
	}
	
}
