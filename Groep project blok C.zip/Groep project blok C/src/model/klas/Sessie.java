package model.klas;

public class Sessie {
	private Cursus mijnCursus;
	private College mijnCollege;
	private Docent deDocenten;
	private Klas deKlassen;
	
	

}
